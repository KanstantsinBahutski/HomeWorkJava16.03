public class Main {
    public static void main(String[] args) {
        long lo = 1000L;
        byte newByte = (byte) lo;
        short newShort = (short) lo;
        int newInt = (int) lo;
        double newDouble = lo;
        System.out.println(newByte);
        System.out.println(newShort);
        System.out.println(newInt);
        System.out.println(newDouble);
    }
}