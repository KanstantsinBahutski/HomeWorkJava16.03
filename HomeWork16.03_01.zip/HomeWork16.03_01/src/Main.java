public class Main {
    public static void main(String[] args) {
        byte b = 1;
        short newShort = b;
        int newInt = b;
        long newLong = b;
        double newDouble = b;
        System.out.println(newShort);
        System.out.println(newInt);
        System.out.println(newLong);
        System.out.println(newDouble);
    }
}