public class Main {
    public static void main(String[] args) {
        String newString = "I study Basic Java!";
        System.out.println(newString.charAt(0));
        System.out.println(newString.length());
        System.out.println(newString.charAt(18));
        System.out.println(newString.contains("Java"));
        System.out.println(newString.replace("a", "o"));
        System.out.println(newString.toUpperCase());
        System.out.println(newString.toLowerCase());
        System.out.println(newString.substring(14, 18));
    }
}